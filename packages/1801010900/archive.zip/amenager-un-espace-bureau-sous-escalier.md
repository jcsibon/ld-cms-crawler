## La mise en place des fixations de vos étagères sous escalier
Commencez par prendre les mesures de la hauteur de marche, du giron, et de l’espace entre le mur et la contremarche. Pour installer les fixations des barres de supports d’étagères, reportez les emplacements des vis grâce au gabarit. Pré-percez, puis fixez solidement à la marche.
![desktop_AMENespacbureauSSescalier_bureauSSescalier](//statics.lapeyre.fr/img/contrib/2bdd4da30020948c/desktop_AMENespacbureauSSescalier_bureauSSescalier.jpg)
##
## La mise en place des étagères de rangement
Réduisez la taille de chaque tube inox grâce à une simple découpe, puis enfoncez ce derniers dans les supports d’étagères et serrez-les avec la clef Allen. Dessinez les trous de perçage de la planche. Vous pourrez ainsi glisser les étagères dans les tubes et les fixer par des vis pointeaux.
## L'assemblage du bureau sous escalier
Les étagères installées, il ne reste plus qu’à assembler le bureau. Vérifiez que la planche est à la bonne mesure et recoupez-la en cas de besoin. Reportez les repères de fixation des pieds, pré-percez puis vissez les supports des pieds. Ceux-ci s’enclenchent très facilement. Vérifiez chaque pied réglable pour que le bureau sous-escalier soit bien horizontal. C’est fini !