## Choisir l’ouverture de votre placard sous escalier Déclic
La gamme de placards Déclic vous permet tout d’abord de choisir le type d’ouverture de votre **[placard](/placards-dressing-CCU0005/portes-placard-CCN0084)** sous escalier.
Pour un placard sous escalier classique, optez pour des portes battantes Déclic. Cet aménagement sur mesure vous permet d'installer de nombreuses étagères.
Pour un aménagement original, adoptez les portes de placard coulissantes Déclic. Ce placard réalisé sur mesure est composé de caissons standard dont l’ouverture est guidée par des glissières assistées de roulettes.
## Choisir la couleur des portes de votre placard sous escalier Déclic
Avec la gamme Déclic, l’espace sous votre escalier va se métamorphoser en un clin d’œil. Place aux portes de placard Déclic tendance ! A vous de choisir entre les finitions bois (sapin, chêne ou bois exotique), ou l’option couleur à la carte.
Avec tant de possibilités, vous allez passer plus de temps à vous décider qu’à installer votre placard sous escalier !