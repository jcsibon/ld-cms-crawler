## Dressing design ou placard sur mesure ?
Les options de rangement sont aussi variées que les types de logements. Lapeyre a eu la bonne idée de créer l’[**aménagement de placard Brooklyn**](/amenagement-brooklyn-FPC2380360)et l’aménagement Dubaï, qui répondent à (presque) toutes vos nécessités.
Ces rangements modulables s’adaptent à la largeur de votre niche. [**L’aménagement Espace**](/amenagement-espace-tringle-recoupable-FPC0234170), quant à lui, vous invite à choisir vos rangements et leur organisation.
![desktop_AMENplacardavosmesurepetitprix_brooklyn_p1](//statics.lapeyre.fr/img/contrib/2bdd4da30020896f/desktop_AMENplacardavosmesurepetitprix_brooklyn_p1.jpg)
##
## Vos portes de placard sur mesure à moindre prix
Votre niche équipée et transformée en placard, dotez-la d’une [**porte coulissante Apparence**](/portes-coulissantes-apparence-2-vantaux-decors-FPC2220860). D’une hauteur maximale de 2,50 m, elle se recoupe en hauteur et en largeur pour s’adapter parfaitement à vos mesures.
Avec différents tons de bois à combiner à des effets matières, et la possibilité d’ajouter des baguettes acier à coller, le rendu de ces portes est vraiment sur mesure.
Les portes de placard contemporaines Lapeyre prennent soin de votre décoration intérieure et de votre porte-monnaie !