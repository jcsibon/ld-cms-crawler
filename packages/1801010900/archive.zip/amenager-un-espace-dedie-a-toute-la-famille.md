## La cuisine Lapeyre, centre névralgique de la maison
Pensez ainsi à un [**aménagement de cuisine**](/cuisine-CCU0001) basé sur un grand [**plan de travail**](/cuisine-CCU0001/credences-plans-travail-CCN0013/plans-travail-CCN0091) pour cuisiner pendant que vos enfants font leurs devoirs sur la table.
Ou dotez votre cuisine d’un îlot central qui vous permet de vaquer à vos occupations sans leur tourner le dos. Pour le rangement de cuisine, pensez à un meuble banc où les affaires scolaires peuvent rapidement être gardées, mais aussi à un meuble suspendu. Idéal pour stocker les cartables en dessous…
![desktop_ESPfamiliauxmieuxagence_meublenewport_p1](//statics.lapeyre.fr/img/contrib/2bdd4da30020d000/desktop_ESPfamiliauxmieuxagence_meublenewport_p1.jpg)
##
## La salle de bain, espace familial à partager
L’aménagement de votre salle de bains, doit être pensé avec soin. Jouez la carte du meuble salle de bains malin et intégré. Les meubles de salle de bains Newport ou **[Fokus](/modele-fokus-l-40-cm-colonne-FPC367082)**(suspendus ou sur pied) offrent ainsi une vasque XXL.
Pensez également à munir vos tiroirs de tiroirs avec séparateurs amovibles pour ordonner les affaires de chacun.
## L’entrée de la maison, lieu de transition stratégique
Dans l’entrée, réunissez les manteaux de votre tribu dans un dressing avec l’aménagement modulaire Espace ou prêt-à-poser Dubaï.
Retrouvez une entrée parfaitement organisée !